package com.example.firebase_application

data class AuthTable(val id:String?, val username:String?, val password:String?)