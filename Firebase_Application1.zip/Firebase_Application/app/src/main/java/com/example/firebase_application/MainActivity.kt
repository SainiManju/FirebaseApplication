package com.example.firebase_application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var refRoot= FirebaseDatabase.getInstance().reference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        activity_main_register.setOnClickListener {
            var key=refRoot.push().key.toString()
            var user=User(editText_firstname.text.toString(),editText_email.text.toString(),user_phone_EditText.text.toString(),user_Description_EditText.text.toString())
            refRoot.child("users").child(key).setValue(user)
            val ref=FirebaseDatabase.getInstance().getReference("AuthTable/").child(key)

            ref.child("Id").setValue(key)
            ref.child("username").setValue(user.Email)
            ref.child("password").setValue(user.Name)
            Toast.makeText(applicationContext,"Check Database", Toast.LENGTH_SHORT).show()
        }
    }

}
