package com.example.firebase_application

data class User(val Name:String?, val Email:String?, val Phone: String?, val Description:String?) {
    constructor() : this("", "", "", "")

}

